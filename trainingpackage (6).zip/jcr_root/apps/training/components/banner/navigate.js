use(function () {

 var title = currentPage.getPath();
    console.log(title);
   var link= properties.get("buttonlink",title);

     link=link+".html";
 return {
 Link : link
 };
});